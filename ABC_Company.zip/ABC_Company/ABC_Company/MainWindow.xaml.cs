﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ABC_Company
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static string connectionstring = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        SqlConnection connection = new SqlConnection(connectionstring);
        SqlCommand command;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayData();     // display method               
        }
        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {           
            DisplayUserDetails();       //    Display user Details Method             
        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            DeleteUserDetails();
            DisplayData();
            ClearData();           //          To Clear textbox after operation performed
        }
        //       Displaying user Data           
        public void DisplayData()
        {
            connection = new SqlConnection(connectionstring);
            SqlDataReader dataReader;
            try
            {
                string newQuery = "SELECT * FROM ABC_Company_46023355";
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                dataReader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                dgUsers.DataContext = dataTable;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        //       Displaying Required user details                
        private void DisplayUserDetails()
        {
            SqlDataReader dataReader;
            try
            {
                string newQuery = "SELECT * FROM ABC_Company_46023355 WHERE User_ID=" + int.Parse(txtUserID.Text);
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    txtUserName.Text = dataReader["User_Name"].ToString();
                    txtEmail.Text = dataReader["User_Email"].ToString();
                    txtCountry.Text = dataReader["User_Country"].ToString();
                    txtContactNumber.Text = dataReader["User_ContactNumber"].ToString();
                    txtAddress.Text = dataReader["Address"].ToString();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        //     Deleting user details              
        private void DeleteUserDetails()
        {
            try
            {
                string newQuery = "DELETE FROM ABC_Company_46023355 WHERE User_ID=" + int.Parse(txtUserID.Text);
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                int recordsDeleted = command.ExecuteNonQuery();
                if (recordsDeleted > 0)
                {
                    MessageBox.Show("User Information Deleted successfully");
                }
                else
                    MessageBox.Show("Error in Deleting Information!!");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        //       to clear textboxes after operations performed            
        public void ClearData()
        {
            txtUserID.Text = "";
            txtUserName.Text = "";
            txtEmail.Text = "";
            txtCountry.Text = "";
            txtContactNumber.Text = "";
            txtAddress.Text = "";
        }
    }  
}
